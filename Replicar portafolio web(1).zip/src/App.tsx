import { useState, useEffect, useRef, useCallback } from 'react'

const SCRAMBLE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&'
const NAMES = ['Ali Erazo', 'Akku']

function useScrambleCycle() {
  const [display, setDisplay] = useState(NAMES[0])
  const nameIndex = useRef(0)
  const frameRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const scrambleTo = useCallback((target: string) => {
    let iteration = 0
    const totalFrames = 18
    const scramble = () => {
      setDisplay(
        target
          .split('')
          .map((char, i) => {
            if (char === ' ') return ' '
            if (i < iteration / (totalFrames / target.length)) return char
            return SCRAMBLE_CHARS[Math.floor(Math.random() * SCRAMBLE_CHARS.length)]
          })
          .join('')
      )
      iteration++
      if (iteration <= totalFrames) {
        frameRef.current = setTimeout(scramble, 40)
      } else {
        setDisplay(target)
      }
    }
    scramble()
  }, [])

  useEffect(() => {
    const cycle = () => {
      nameIndex.current = (nameIndex.current + 1) % NAMES.length
      scrambleTo(NAMES[nameIndex.current])
    }
    const interval = setInterval(cycle, 5000)
    return () => {
      clearInterval(interval)
      if (frameRef.current) clearTimeout(frameRef.current)
    }
  }, [scrambleTo])

  return display
}

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Experience', href: '#experience' },
  { label: 'Contact', href: '#contact' },
]

const FRONTEND_SKILLS = ['React', 'JavaScript', 'TypeScript', 'Tailwind CSS v4', 'Htmx', 'CSS3 / HTML5']
const BACKEND_SKILLS = ['PHP', 'C#', 'Python', 'ASP.NET', '.NET Core', 'Docker']
const PLATFORM_SKILLS = ['GitHub', 'n8n', 'Cursor', 'Sigma', 'ClickUp', 'Claude AI', 'Deepseek']

const PROJECTS = [
  {
    name: 'Carguard',
    description:
      'A small project created to help security guards at their parking facility keep track of vehicle owners\' information, recording entries and exits of people.',
    tags: ['PHP', 'MySQL', 'Bootstrap'],
    status: 'Completed',
  },
]

const EXPERIENCE = [
  {
    org: 'Universidad Autónoma del Caribe',
    location: 'On-site · Colombia',
    period: '2024',
    bullets: [
      'Developed an n8n-based chatbot using RAG and rate limiting, with 6 security layers to control how the chatbot responds.',
      'Made an entry software documentation for new developers, with a visual summary of the technologies that the university uses.',
      'Integrated React views with APIs REST, using data retrieved from the DB2 database through the backend to create a dynamic experience for the user.',
    ],
  },
]

function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true) },
      { threshold }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [threshold])
  return { ref, inView }
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2
      className="text-3xl md:text-4xl font-bold text-center mb-12"
      style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
    >
      {children}
    </h2>
  )
}

function SkillCard({
  title,
  items,
  delay = 0,
}: {
  title: string
  items: string[]
  delay?: number
}) {
  const { ref, inView } = useInView()
  return (
    <div
      ref={ref}
      className="rounded-xl p-6 flex flex-col gap-3 border transition-all duration-700"
      style={{
        background: '#2e2d37',
        borderColor: '#4f9ab9',
        borderWidth: '1px',
        opacity: inView ? 1 : 0,
        transform: inView ? 'translateY(0)' : 'translateY(24px)',
        transitionDelay: `${delay}ms`,
        boxShadow: inView ? '0 4px 32px rgba(79,154,185,0.10)' : 'none',
      }}
    >
      <h3
        className="text-sm font-semibold tracking-widest uppercase mb-1"
        style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
      >
        {title}
      </h3>
      <ul className="flex flex-wrap gap-2">
        {items.map((item) => (
          <li
            key={item}
            className="text-sm px-3 py-1 rounded-full"
            style={{
              background: 'rgba(79,154,185,0.12)',
              color: '#6ab8d4',
              fontFamily: 'JetBrains Mono, monospace',
            }}
          >
            {item}
          </li>
        ))}
      </ul>
    </div>
  )
}

function ContactForm() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validate = () => {
    const e: Record<string, string> = {}
    if (!form.name.trim()) e.name = 'Name is required'
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) e.email = 'Valid email required'
    if (!form.message.trim()) e.message = 'Message is required'
    return e
  }

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault()
    const e = validate()
    if (Object.keys(e).length) { setErrors(e); return }
    setErrors({})
    setSent(true)
  }

  if (sent) {
    return (
      <div
        className="flex flex-col items-center justify-center gap-4 py-12 rounded-xl"
        style={{ background: '#2e2d37', border: '1px solid #4f9ab9' }}
      >
        <span className="text-4xl">✓</span>
        <p className="text-lg font-semibold" style={{ color: '#4f9ab9', fontFamily: 'JetBrains Mono, monospace' }}>
          Message sent!
        </p>
        <p className="text-sm" style={{ color: '#9898a8' }}>I'll get back to you soon.</p>
        <button
          onClick={() => { setSent(false); setForm({ name: '', email: '', message: '' }) }}
          className="mt-2 text-sm underline"
          style={{ color: '#4f9ab9' }}
        >
          Send another
        </button>
      </div>
    )
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex flex-col gap-4 rounded-xl p-6"
      style={{ background: '#2e2d37', border: '1px solid #4f9ab9' }}
      noValidate
    >
      <div className="flex flex-col gap-1">
        <label className="text-xs tracking-widest uppercase" style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}>
          Name
        </label>
        <input
          type="text"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="Ali Erazo"
          className="rounded-lg px-4 py-3 text-sm outline-none transition-all duration-200"
          style={{
            background: '#35343e',
            border: errors.name ? '1px solid #e05252' : '1px solid #4a4a58',
            color: '#e8e8f0',
            fontFamily: 'Outfit, sans-serif',
          }}
          onFocus={(e) => (e.target.style.borderColor = '#4f9ab9')}
          onBlur={(e) => (e.target.style.borderColor = errors.name ? '#e05252' : '#4a4a58')}
        />
        {errors.name && <span className="text-xs" style={{ color: '#e05252' }}>{errors.name}</span>}
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-xs tracking-widest uppercase" style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}>
          Email
        </label>
        <input
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          placeholder="you@email.com"
          className="rounded-lg px-4 py-3 text-sm outline-none transition-all duration-200"
          style={{
            background: '#35343e',
            border: errors.email ? '1px solid #e05252' : '1px solid #4a4a58',
            color: '#e8e8f0',
            fontFamily: 'Outfit, sans-serif',
          }}
          onFocus={(e) => (e.target.style.borderColor = '#4f9ab9')}
          onBlur={(e) => (e.target.style.borderColor = errors.email ? '#e05252' : '#4a4a58')}
        />
        {errors.email && <span className="text-xs" style={{ color: '#e05252' }}>{errors.email}</span>}
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-xs tracking-widest uppercase" style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}>
          Message
        </label>
        <textarea
          rows={5}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          placeholder="Hi Ali, I'd love to work with you on..."
          className="rounded-lg px-4 py-3 text-sm outline-none transition-all duration-200 resize-none"
          style={{
            background: '#35343e',
            border: errors.message ? '1px solid #e05252' : '1px solid #4a4a58',
            color: '#e8e8f0',
            fontFamily: 'Outfit, sans-serif',
          }}
          onFocus={(e) => (e.target.style.borderColor = '#4f9ab9')}
          onBlur={(e) => (e.target.style.borderColor = errors.message ? '#e05252' : '#4a4a58')}
        />
        {errors.message && <span className="text-xs" style={{ color: '#e05252' }}>{errors.message}</span>}
      </div>

      <button
        type="submit"
        className="mt-1 py-3 px-6 rounded-lg font-semibold text-sm tracking-wider uppercase transition-all duration-200 hover:brightness-110 active:scale-95"
        style={{
          background: '#4f9ab9',
          color: '#1a1a22',
          fontFamily: 'JetBrains Mono, monospace',
        }}
      >
        Send message
      </button>
    </form>
  )
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const scrambledName = useScrambleCycle()

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const heroInView = useInView(0.1)
  const aboutInView = useInView(0.15)
  const projectsInView = useInView(0.1)
  const expInView = useInView(0.1)
  const contactInView = useInView(0.1)

  return (
    <div className="min-h-screen" style={{ background: '#35343e', color: '#e8e8f0', fontFamily: 'Outfit, sans-serif' }}>

      {/* NAV */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? 'rgba(35,34,46,0.95)' : 'transparent',
          backdropFilter: scrolled ? 'blur(12px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(79,154,185,0.15)' : 'none',
        }}
      >
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <span
            className="text-base font-bold tracking-tight"
            style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
          >
            ali.dev
          </span>

          <div className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm transition-colors duration-150 hover:text-teal-400"
                style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}
                onMouseEnter={(e) => ((e.target as HTMLElement).style.color = '#4f9ab9')}
                onMouseLeave={(e) => ((e.target as HTMLElement).style.color = '#9898a8')}
              >
                {l.label}
              </a>
            ))}
          </div>

          <button
            className="md:hidden p-2 rounded"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
            style={{ color: '#4f9ab9' }}
          >
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>

        {menuOpen && (
          <div
            className="md:hidden px-6 pb-6 flex flex-col gap-4"
            style={{ background: 'rgba(35,34,46,0.97)' }}
          >
            {NAV_LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setMenuOpen(false)}
                className="text-sm"
                style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}
              >
                {l.label}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* HERO */}
      <section
        className="min-h-screen flex flex-col items-center justify-center text-center px-6 pt-24 pb-16"
        style={{
          background: 'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(79,154,185,0.08) 0%, transparent 70%)',
        }}
      >
        <div
          ref={heroInView.ref}
          className="transition-all duration-1000"
          style={{
            opacity: heroInView.inView ? 1 : 0,
            transform: heroInView.inView ? 'translateY(0)' : 'translateY(32px)',
          }}
        >
          <p
            className="text-sm tracking-[0.25em] uppercase mb-4"
            style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}
          >
            Are you looking for a
          </p>
          <h1
            className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6"
            style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
          >
            Analyst &amp;<br />Software Developer?
          </h1>
          <p
            className="text-lg md:text-xl mb-10"
            style={{ color: '#e8e8f0' }}
          >
            Hi, I'm <span style={{ color: '#4f9ab9', fontFamily: 'JetBrains Mono, monospace' }}>{scrambledName}.</span>
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="#about"
              className="px-7 py-3 rounded-lg text-sm font-semibold uppercase tracking-wider transition-all duration-200 hover:brightness-110"
              style={{
                background: '#4f9ab9',
                color: '#1a1a22',
                fontFamily: 'JetBrains Mono, monospace',
              }}
            >
              About me
            </a>
            <a
              href="#experience"
              className="px-7 py-3 rounded-lg text-sm font-semibold uppercase tracking-wider transition-all duration-200"
              style={{
                border: '1px solid #4f9ab9',
                color: '#4f9ab9',
                fontFamily: 'JetBrains Mono, monospace',
                background: 'transparent',
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget
                el.style.background = 'rgba(79,154,185,0.12)'
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget
                el.style.background = 'transparent'
              }}
            >
              Experience
            </a>
          </div>
        </div>

        <div
          className="mt-16 animate-bounce"
          style={{ color: '#4f9ab9', opacity: 0.5 }}
        >
          ↓
        </div>
      </section>

      {/* SKILLS */}
      <section id="skills" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <SectionTitle>My Skillset</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <SkillCard title="Frontend" items={FRONTEND_SKILLS} delay={0} />
            <SkillCard title="Platforms & Tools" items={PLATFORM_SKILLS} delay={100} />
            <SkillCard title="Backend" items={BACKEND_SKILLS} delay={200} />
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <SectionTitle>About me</SectionTitle>
          <div
            ref={aboutInView.ref}
            className="flex flex-col md:flex-row gap-10 items-center md:items-start transition-all duration-700"
            style={{
              opacity: aboutInView.inView ? 1 : 0,
              transform: aboutInView.inView ? 'translateY(0)' : 'translateY(24px)',
            }}
          >
            <div className="flex-shrink-0">
              <div
                className="w-36 h-36 rounded-full overflow-hidden"
                style={{ border: '3px solid #4f9ab9', boxShadow: '0 0 32px rgba(79,154,185,0.25)' }}
              >
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=144&h=144&fit=crop&auto=format"
                  alt="Ali Erazo developer portrait"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="flex flex-col gap-4 text-base leading-relaxed" style={{ color: '#c8c8d8' }}>
              <p>
                My name is Ali Erazo. I'm a junior Analyst and Software Developer with 7 months
                of experience solving problems.
              </p>
              <p>
                I started learning about coding in my teenage as a hobby; lately I began studying
                a career of it at SENA in a technologist course until I completed it.
              </p>
              <p>
                I learned about web applications and currently I'm thinking about start to learn
                about mobile developing for a better user experience with simple mobile applications.
              </p>
              <p>
                I have experience on <span style={{ color: '#4f9ab9' }}>React, PHP, Docker</span> and <span style={{ color: '#4f9ab9' }}>C#</span>.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* PROJECTS */}
      <section id="projects" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <SectionTitle>Projects</SectionTitle>
          <p className="text-center mb-12 text-sm" style={{ color: '#9898a8' }}>
            A small group of projects that I've done or support.
          </p>
          <div
            ref={projectsInView.ref}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 transition-all duration-700"
            style={{
              opacity: projectsInView.inView ? 1 : 0,
              transform: projectsInView.inView ? 'translateY(0)' : 'translateY(24px)',
            }}
          >
            {PROJECTS.map((p) => (
              <div
                key={p.name}
                className="rounded-xl p-6 flex flex-col gap-4"
                style={{
                  background: '#2e2d37',
                  border: '1px solid rgba(79,154,185,0.3)',
                  transition: 'border-color 0.2s, box-shadow 0.2s',
                }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget
                  el.style.borderColor = '#4f9ab9'
                  el.style.boxShadow = '0 4px 32px rgba(79,154,185,0.15)'
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget
                  el.style.borderColor = 'rgba(79,154,185,0.3)'
                  el.style.boxShadow = 'none'
                }}
              >
                <div className="flex items-center justify-between">
                  <h3
                    className="text-lg font-bold"
                    style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
                  >
                    {p.name}
                  </h3>
                  <span
                    className="text-xs px-2 py-1 rounded-full"
                    style={{ background: 'rgba(79,154,185,0.15)', color: '#6ab8d4', fontFamily: 'JetBrains Mono, monospace' }}
                  >
                    {p.status}
                  </span>
                </div>
                <p className="text-sm leading-relaxed" style={{ color: '#c8c8d8' }}>{p.description}</p>
                <div className="flex flex-wrap gap-2 mt-auto">
                  {p.tags.map((t) => (
                    <span
                      key={t}
                      className="text-xs px-2 py-1 rounded"
                      style={{ background: '#35343e', color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* EXPERIENCE */}
      <section id="experience" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <SectionTitle>My Experience</SectionTitle>
          <div
            ref={expInView.ref}
            className="flex flex-col gap-10 transition-all duration-700"
            style={{
              opacity: expInView.inView ? 1 : 0,
              transform: expInView.inView ? 'translateY(0)' : 'translateY(24px)',
            }}
          >
            {EXPERIENCE.map((exp) => (
              <div
                key={exp.org}
                className="rounded-xl p-6"
                style={{ background: '#2e2d37', border: '1px solid rgba(79,154,185,0.2)' }}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-1 mb-4">
                  <div>
                    <h3
                      className="text-lg font-bold"
                      style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
                    >
                      {exp.org}
                    </h3>
                    <p className="text-sm" style={{ color: '#9898a8' }}>{exp.location}</p>
                  </div>
                  <span
                    className="text-xs px-3 py-1 rounded-full self-start md:self-auto"
                    style={{ background: 'rgba(79,154,185,0.12)', color: '#6ab8d4', fontFamily: 'JetBrains Mono, monospace' }}
                  >
                    {exp.period}
                  </span>
                </div>
                <ul className="flex flex-col gap-3">
                  {exp.bullets.map((b, i) => (
                    <li key={i} className="flex gap-3 text-sm leading-relaxed" style={{ color: '#c8c8d8' }}>
                      <span style={{ color: '#4f9ab9', flexShrink: 0, marginTop: '2px' }}>◆</span>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <SectionTitle>Contact me</SectionTitle>
          <div
            ref={contactInView.ref}
            className="grid grid-cols-1 md:grid-cols-2 gap-10 transition-all duration-700"
            style={{
              opacity: contactInView.inView ? 1 : 0,
              transform: contactInView.inView ? 'translateY(0)' : 'translateY(24px)',
            }}
          >
            <ContactForm />

            <div className="flex flex-col gap-6">
              <div>
                <h3
                  className="text-xl font-bold mb-4"
                  style={{ fontFamily: 'JetBrains Mono, monospace', color: '#4f9ab9' }}
                >
                  Social media
                </h3>
                <div className="flex flex-col gap-3">
                  {[
                    { label: 'GitHub', handle: '@ali-erazo', icon: '⌥' },
                    { label: 'LinkedIn', handle: 'Ali Erazo', icon: '⌘' },
                    { label: 'Email', handle: 'ali@email.com', icon: '✉' },
                  ].map((s) => (
                    <a
                      key={s.label}
                      href="#"
                      className="flex items-center gap-4 rounded-xl px-5 py-4 transition-all duration-200"
                      style={{
                        background: '#2e2d37',
                        border: '1px solid rgba(79,154,185,0.2)',
                        color: '#e8e8f0',
                        textDecoration: 'none',
                      }}
                      onMouseEnter={(e) => {
                        const el = e.currentTarget
                        el.style.borderColor = '#4f9ab9'
                        el.style.background = 'rgba(79,154,185,0.08)'
                      }}
                      onMouseLeave={(e) => {
                        const el = e.currentTarget
                        el.style.borderColor = 'rgba(79,154,185,0.2)'
                        el.style.background = '#2e2d37'
                      }}
                    >
                      <span
                        className="w-9 h-9 flex items-center justify-center rounded-lg text-base"
                        style={{ background: 'rgba(79,154,185,0.15)', color: '#4f9ab9' }}
                      >
                        {s.icon}
                      </span>
                      <div className="flex flex-col">
                        <span className="text-xs tracking-widest uppercase" style={{ color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}>
                          {s.label}
                        </span>
                        <span className="text-sm" style={{ color: '#e8e8f0' }}>{s.handle}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>

              <div
                className="rounded-xl p-5 mt-2"
                style={{ background: 'rgba(79,154,185,0.07)', border: '1px solid rgba(79,154,185,0.2)' }}
              >
                <p className="text-sm leading-relaxed" style={{ color: '#9898a8' }}>
                  Currently <span style={{ color: '#4f9ab9' }}>open to opportunities</span> — junior roles, freelance projects, or collaborative builds. Let's create something together.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer
        className="py-8 text-center text-xs"
        style={{ borderTop: '1px solid rgba(79,154,185,0.12)', color: '#9898a8', fontFamily: 'JetBrains Mono, monospace' }}
      >
        <span>© 2026 Ali Erazo — built with React &amp; Tailwind CSS</span>
      </footer>
    </div>
  )
}
